Nobs=10
obs=rcauchy(Nobs)
Nsim=250
Nmc=500
sampl=matrix(rnorm(Nsim*Nmc),nrow=1000) # Muestras normales
raga=riga=matrix(0,nrow=50,ncol=2) # Matriz m�nimos y m�ximos
mu=0
for (j in 1:50){
  prod=1/dnorm(sampl-mu) # Muestreo de importancia
  for (i in 1:Nobs)
  prod=prod*dt(obs[i]-sampl,1)
  esti=apply(sampl*prod,2,sum)/apply(prod,2,sum)
  raga[j,]=range(esti)
  riga[j,]=c(quantile(esti,.025),quantile(esti,.975))
  sampl=sampl+0.1
  mu=mu+0.1
  }
mus=seq(0,4.9,by=0.1)
plot(mus,0*mus,col="white",xlab=expression(mu),
   ylab=expression(hat(theta)),ylim=range(raga))
polygon(c(mus,rev(mus)),c(raga[,1],rev(raga[,2])),col="grey50")
polygon(c(mus,rev(mus)),c(riga[,1],rev(riga[,2])),col="pink3")