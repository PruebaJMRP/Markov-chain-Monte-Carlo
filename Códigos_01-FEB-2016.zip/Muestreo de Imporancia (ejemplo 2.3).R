grand=function(x,nu=3){
  sqrt(abs(x)/abs(1-x))}
N=10^3
sampone=rt(N,df=3)
samptwo=rcauchy(N)
samptre=rnorm(N)
weitwo=dt(samptwo,df=3)/dcauchy(samptwo)
weitre=dt(samptre,df=3)/dnorm(samptre)
plot(cumsum(grand(samptwo)*weitwo)/(1:N),type="l",
     xlab="simulaciones",ylab="promedio acumulado",lwd=2,col="sienna")
lines(cumsum(grand(samptre)*weitre)/(1:N),col="steelblue",lwd=2)
lines(cumsum(grand(sampone))/(1:N),col="gold2",lwd=2)
alpha=.5
y=rgamma(N,sh=alpha)
x=sample(c(-1,1),N,rep=TRUE)*y+1
weiqar=2*dt(x,df=3)/dgamma(y,sh=alpha)
lines(cumsum(grand(y)*weiqar)/(1:N),col="tomato",lwd=2)
