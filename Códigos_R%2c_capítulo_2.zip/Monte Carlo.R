n=100
N=1000000
nu=2*n-2
barx=.088
bary=.1078
mu=.5*(bary-barx)
stwo=.00875
sigma=sqrt(.5*stwo/nu)
C=log(stwo)*(-n+.5)+log(sigma*sqrt(nu*pi))+
  lgamma(.5*nu)-lgamma(.5*nu+.5)
# Simulaci�n T
xis=rt(n=N,df=nu)*sigma + mu
B01=-log(cumsum(dnorm(xis))/(1:N))
B01=exp( (-n+.5)*log(.5*(barx-bary)^2+stwo)+B01-C )
# Simulaci�n Normal
xis=rnorm(N)
C01=cumsum((stwo+.5*(2*xis+barx-bary)^2)^(-n+.5))/(1:N)
C01=((.5*(barx-bary)^2+stwo)^(-n+.5))/C01
# Comparaci�n
plot(C01[seq(1,N,l=1000)],type="l",col="tomato2",lwd=2,
     ylim=c(20,30),xlab=expression(N/100),ylab=expression(1/B[10]))
lines(B01[seq(1,N,l=1000)],col="steelblue3",lwd=2,lty=5)
