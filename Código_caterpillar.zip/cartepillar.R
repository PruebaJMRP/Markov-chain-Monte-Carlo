oruga <- read.table("C:/Users/Alejandro Labarca/Desktop/MCMC/caterpillar.txt", quote="\"", comment.char="")
oruga$V11=log(oruga$V11)
test=summary(lm(V11~V1+V2+V3+V4+V5+V6+V7+V8+V9+V10,oruga))
betatilde=test[[4]][1:11]
cc=1:10e5
y=oruga$V11
X=as.matrix(cbind(rep(1,33),oruga[,1:10]))
P=X%*%solve(t(X)%*%X)%*%t(X)
factor_beta=sum(cc/(cc+1)*cc^(-2)*(cc+1)^(-11/2)*
          (t(y)%*%y-cc/(cc+1)*t(y)%*%P%*%y)^(-33/2))/
           sum(cc^(-2)*(cc+1)^(-11/2)*(t(y)%*%y-cc/
           (cc+1)*t(y)%*%P%*%y)^(-33/2))
test_bayes_beta=factor_beta*betatilde
sd=t(y-X%*%betatilde)%*%(y-X%*%betatilde)
factor_sd1=(sum(((((cc+1)^(-11/2))*(t(y)%*%y-cc/
                (cc+1)*t(y)%*%P%*%y)^(-33/2))/
                (33*(cc+1)))*((sd+(t(betatilde)
                %*%(t(X)%*%X)%*%betatilde)))/(cc+1))/
            sum((((cc+1)^(-11/2))*(t(y)%*%y-cc/
                (cc+1)*t(y)%*%P%*%y)^(-33/2))*(cc^-2)))
factor_sd2=sum((((cc/(cc+1))-factor_beta)^2)*
           (((cc+1)^(-11/2))*(t(y)%*%y-cc/
            (cc+1)*t(y)%*%P%*%y)^(-33/2))*(cc^-2))
XX=solve(t(X)%*%X)            
test_bayes_sd=((factor_sd1*XX))+
              (as.matrix(betatilde*factor_sd2)%*%t(betatilde))           


