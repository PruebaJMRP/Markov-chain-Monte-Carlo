#Distribuci�n predictiva
normaldata <- read.table("C:/Users/marycarmen/Desktop/MCMC/normaldata.txt", quote="\"", comment.char="")
normal=as.numeric(as.matrix(normaldata))
m=mean(normal)
s_2=sd(normal)^2
t_student=function(x,g,mu,sigma){
  t_student=(gamma((g+1)/2)/(sigma*sqrt(g*pi)*gamma(g/2)))*((1+(((x-mu)^2)/(g*(sigma^2))))^-((g+1)/2))
  return(t_student)
}
curve(t_student(x,90,-0.0413,0.136),-0.6,0.6,add=TRUE)
hist(normal,breaks=15,freq=FALSE)

#Detecci�n de outliers
n=length(normal)
outl=rep(0,n)
for (i in 1:n){
  lomean=mean(normal[-i])
  losd=sd(normal[-i])
  outl[i]=pt((normal[i]-lomean)/losd,df=90)
}
plot(c(0,1),c(0,1),lwd=2,ylab="Predictive",xlab="Uniform",
     type="l")
points((1:n)/(n),sort(outl),pch=19,col="steelblue3")
points((1:n)/(n),sort(runif(n)),pch=19,col="tomato")

