#install.packages("mnormt")

#######Funciones##########

probitll=function(beta,y,X)
{
  
  # LOG-LIKELIHOOD OF beta PARA EL PROBIT MODEL
  # LOG-POSTERIOR DE beta PARA EL MODELO PROBIT BAJO FLAT PRIOR
  
  lF1=pnorm(X%*%as.vector(beta),log.p=TRUE)
  lF2=pnorm(-X%*%as.vector(beta),log.p=TRUE)
  sum(y*lF1+(1-y)*lF2)
  
}

hmflatprobit=function(niter,y,X,scale)
{
  
  #UN MUESTREO MH PASEO ALEATORIO GAUSSIANO PARA EL MODELO PROBIT
  # BAJO FLAT PRIOR
  
  library(mnormt)
  p=dim(X)[2]
  mod=summary(glm(y~-1+X,family=binomial(link="probit")))
  beta=matrix(0,niter,p)
  beta[1,]=as.vector(mod$coeff[,1])
  Sigma2=as.matrix(mod$cov.unscaled)
  for (i in 2:niter)
  {
    tildebeta=rmnorm(1,beta[i-1,],scale*Sigma2)
    llr=probitll(tildebeta,y,X)-probitll(beta[i-1,],y,X)
    if (runif(1)<=exp(llr)) beta[i,]=tildebeta else beta[i,]=beta[i-1,]
  }
  beta
}

######Corrida######


#Carga de datos
bank=read.table(file="bank.txt")
bank=as.matrix(bank)

y=bank[,5]
X=bank[,1:4]

#Ejercicio 4.10

X=as.matrix(cbind(rep(1,dim(X)[1]),X))

flatprobit=hmflatprobit(10000,y,X,1)
par(mfrow=c(5,3),mar=1+c(1.5,1.5,1.5,1.5))
for (i in 1:5){
  plot(flatprobit[,i],type="l",xlab="Iterations",
       ylab=expression(beta[i]))
  hist(flatprobit[1001:10000,i],nclass=50,prob=T,main="",
       xlab=expression(beta[i]))
  acf(flatprobit[1001:10000,i],lag=1000,main="",
      ylab="Autocorrelation",ci=F)
}
m_o=mean(flatprobit[1001:10000,1])
m_1=mean(flatprobit[1001:10000,2])
m_2=mean(flatprobit[1001:10000,3])
m_3=mean(flatprobit[1001:10000,4])
m_4=mean(flatprobit[1001:10000,5])
pnorm(m_1*214.9+m_2*130.1+m_3*129.9+m_4*9.5+m_o)

sd=sd(flatprobit[1001:10000,1])^2


